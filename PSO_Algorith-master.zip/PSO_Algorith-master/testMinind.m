A = [1 2 3; 4 5 6; 7 18 9];
[min X Y] = minind(A)